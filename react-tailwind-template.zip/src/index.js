import React from "react";
import ReactDOM from "react-dom/client";
import "./index.css";

function App() {
  return <div className="text-3xl font-bold text-center mt-10 text-blue-500">Hello React + Tailwind!</div>;
}

const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(<App />);
